<?php

namespace App\Http\Controllers\Api\Auth;

use App\Events\RegistrationNotificationEvent;
use Exception;
use Carbon\Carbon;
use App\Models\User;
use App\Mail\OtpMail;
use App\Helpers\Helper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use App\Mail\RegisterOtpMail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use App\Notifications\RegistrationNotification;
use App\Traits\ApiResponse;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class RegisterController extends Controller
{

    use ApiResponse;



    public $select;
    public function __construct()
    {
        $this->select = ['id', 'first_name', 'last_name', 'phone_number', 'email', 'otp', 'avatar'];
    }

    public function register(Request $request)
    {
        $request->validate([
            'first_name'       => 'required|string|max:100',
            'last_name'       => 'required|string|max:100',
            'email'      => 'required|string|email|max:150|unique:users',
            'phone_number'   => 'required|string|regex:/^[0-9+\-\s\(\)]+$/|max:15|unique:users',
            'password'   => 'required|string|min:6|confirmed',

        ]);
        try {

            $user = User::create([
                'first_name'           => $request->input('first_name'),
                'last_name'           => $request->input('last_name'),
                'phone_number'           => $request->input('phone_number'),
                'email'          => strtolower($request->input('email')),
                'password'       => Hash::make($request->input('password')),
                'otp'            => rand(1000, 9999),
                'otp_expires_at' => Carbon::now()->addMinutes(10),
            ]);

            DB::table('model_has_roles')->insert([
                'role_id' => 4,
                'model_type' => 'App\Models\User',
                'model_id' => $user->id
            ]);

            //notify to admin start
            // $notiData = [
            //     'user_id' => $user->id,
            //     'title' => 'User register in successfully.',
            //     'body' => 'User register in successfully.'
            // ];

            // $admins = User::role('admin', 'web')->get();
            // foreach($admins as $admin){
            //     $admin->notify(new RegistrationNotification($notiData));
            //     if(config('settings.reverb')  === 'on'){
            //         broadcast(new RegistrationNotificationEvent($notiData, $admin->id))->toOthers();
            //     }
            // }
            //notify to admin end

            $otp = $user->otp;
            $email = $user->email;

            // Mail::to($email)->send(new RegisterOtpMail($otp, $user, 'Reset Your Password'));


            $data = User::select($this->select)->with('roles')->find($user->id);

            $token = auth('api')->login($user);
            $data->token = $token;
            $data->expires_in = auth('api')->factory()->getTTL() * 60;


            return response()->json([
                'status'     => true,
                'message'    => 'User register in successfully.',
                'code'       => 200,
                'expires_in' => auth('api')->factory()->getTTL() * 60,
                'data' => $data
            ], 200);
        } catch (Exception $e) {
            return Helper::jsonErrorResponse('User registration failed', 500, [$e->getMessage()]);
        }
    }
    public function VerifyEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'otp'   => 'required|digits:4',
        ]);
        try {
            $user = User::where('email', $request->input('email'))->first();

            //! Check if email has already been verified
            if (!empty($user->otp_verified_at)) {
                return  Helper::jsonErrorResponse('Email already verified.', 409);
            }

            if ((string)$user->otp !== (string)$request->input('otp')) {
                return Helper::jsonErrorResponse('Invalid OTP code', 422);
            }

            //* Check if OTP has expired
            if (Carbon::parse($user->otp_expires_at)->isPast()) {
                return Helper::jsonErrorResponse('OTP has expired. Please request a new OTP.', 422);
            }

            //* Verify the email
            $user->otp_verified_at   = now();
            $user->otp               = null;
            $user->otp_expires_at    = null;
            $user->save();

            return Helper::jsonResponse(true, 'Email verification successful.', 200, $user);
        } catch (Exception $e) {
            return Helper::jsonErrorResponse($e->getMessage(), $e->getCode());
        }
    }

    public function ResendOtp(Request $request)
    {

        $request->validate([
            'email' => 'required|email|exists:users,email',
        ]);

        try {
            $user = User::where('email', $request->input('email'))->first();

            if (!$user) {
                return Helper::jsonErrorResponse('User not found.', 404);
            }

            if ($user->otp_verified_at) {
                return Helper::jsonErrorResponse('Email already verified.', 409);
            }

            $newOtp               = rand(1000, 9999);
            $otpExpiresAt         = Carbon::now()->addMinutes(60);
            $user->otp            = $newOtp;
            $user->otp_expires_at = $otpExpiresAt;
            $user->save();

            //* Send the new OTP to the user's email
            // Mail::to($user->email)->send(new OtpMail($newOtp, $user, 'Verify Your Email Address'));

            return response()->json([
                'status'     => true,
                'message'    => 'New Otp send successfully.',
                'code'       => 200,
                'expires_in' => auth('api')->factory()->getTTL() * 60,
                'data' => $user
            ], 200);
        } catch (Exception $e) {
            return Helper::jsonErrorResponse($e->getMessage(), 200);
        }
    }
}
