<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Calories extends Model
{
    protected $guarded = ['id'];
    
}
