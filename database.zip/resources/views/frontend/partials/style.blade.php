<!-- FAVICON -->
<link rel="shortcut icon" type="image/x-icon" href="{{ asset('frontend') }}/images/brand/favicon.ico" />

<!-- TITLE -->
<title>Noa - Laravel Bootstrap 5 Admin & Dashboard Template</title>

<!-- BOOTSTRAP CSS -->
<link id="style" href="{{ asset('frontend') }}/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />

<!-- STYLE CSS -->
<link href="{{ asset('frontend') }}/css/style.css" rel="stylesheet"/>

<!--- FONT-ICONS CSS -->
<link href="{{ asset('frontend') }}/plugins/icons/icons.css" rel="stylesheet"/>

<!-- INTERNAL Switcher css -->
<link href="{{ asset('frontend') }}/switcher/css/switcher.css" rel="stylesheet" />
<link href="{{ asset('frontend') }}/switcher/demo.css" rel="stylesheet" />
@stack('style')