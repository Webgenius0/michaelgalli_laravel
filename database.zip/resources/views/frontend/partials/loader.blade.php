<div id="global-loader">
    <img src="{{ asset('frontend') }}/images/loader.svg" class="loader-img" alt="Loader">
</div>