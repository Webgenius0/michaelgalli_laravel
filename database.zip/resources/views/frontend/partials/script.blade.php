<!-- BACK-TO-TOP -->
<a href="#top" id="back-to-top"><i class="fa fa-long-arrow-up"></i></a>

<!-- JQUERY JS -->
<script src="{{ asset('frontend') }}/plugins/jquery/jquery.min.js"></script>

<!-- BOOTSTRAP JS -->
<script src="{{ asset('frontend') }}/plugins/bootstrap/js/popper.min.js"></script>
<script src="{{ asset('frontend') }}/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- Owl carousel JS -->
<script src="{{ asset('frontend') }}/plugins/company-slider/slider.js"></script>
<script src="{{ asset('frontend') }}/plugins/owl-carousel/owl.carousel.js"></script>

<!-- landing JS -->
<script src="{{ asset('frontend') }}/js/landing.js"></script>

@stack('script')