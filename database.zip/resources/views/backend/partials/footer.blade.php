       <footer class="footer">
           <div class="container">
               <div class="row align-items-center flex-row-reverse">
                   <div class="col-md-12 col-sm-12 text-center">
                        {{ date('Y') }} &copy; {{ ucfirst(config('app.name')) }}
                       <!-- Copyright © 2022 <a href="#">Noa</a>. Designed with <span class="fa fa-heart text-danger"></span> by <a href="#"> Spruko </a> All rights reserved -->
                   </div>
               </div>
           </div>
       </footer>
