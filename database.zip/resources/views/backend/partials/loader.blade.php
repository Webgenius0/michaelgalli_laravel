<!-- GLOBAL-LOADER -->
<div id="global-loader">
    <img src="{{ asset('default/loader.gif') }}" class="loader-img" alt="Loader" style="width: 100px;">
</div>
<!-- /GLOBAL-LOADER -->
