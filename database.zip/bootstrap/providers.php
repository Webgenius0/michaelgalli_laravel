<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\RepositoryServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
];
